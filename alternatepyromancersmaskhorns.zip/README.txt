STEPS TO INSTALL:
Step 1: Pick one.
Step 2: Drag and drop the .vpk file to your /Team Fortress 2/tf/custom folder.
Step 3: Launch your game and enjoy.